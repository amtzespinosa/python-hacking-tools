#!/bin/bash

pip3 install whois
pip3 install dnspython

cp -r dns-recon/ /usr/lib/dnsrecon/
cp dnsrecon /usr/bin/
chmod +x /usr/bin/dnsrecon
cp dnsrecon-uninstall /usr/bin/
chmod +x /usr/bin/dnsrecon-uninstall

