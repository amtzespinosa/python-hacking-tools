#!/bin/bash

pip install scapy

cp -r arp-tool/ /usr/lib/arptool/
cp arptool /usr/bin/
chmod +x /usr/bin/arptool
cp arptool-uninstall /usr/bin/
chmod +x /usr/bin/arptool-uninstall

